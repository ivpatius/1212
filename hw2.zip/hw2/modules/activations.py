import numpy as np
from modules.base import Module
from scipy.special import log_softmax

class ReLU(Module):
    """
    Применяет поэлементную функцию ReLU (Rectified Linear Unit).
    """
    def compute_output(self, input):
        """
        Вычисляет прямой проход слоя.

        :param input: входной массив произвольной формы
        :return: выходной массив той же формы

        """
        self.mask = (input > 0).astype(float)
        return input * self.mask

    def compute_grad_input(self, input, grad_output):
        """
        Вычисляет градиент по входу, используя градиент по выходу.

        :param input: входной массив (тот же, что в forward-проходе)
        :param grad_output: градиент функции потерь по выходу ReLU
        :return: градиент функции потерь по входу ReLU

        Логика:
        - Для положительных входных значений градиент сохраняется
        - Для отрицательных входных значений градиент = 0
        """
        return grad_output * self.mask


class Sigmoid(Module):
    """
    Применяет поэлементную сигмоиду:
    σ(x) = 1 / (1 + exp(-x))
    """

    def compute_output(self, input):
        """
        Вычисляет прямой проход.

        :param input: входной массив
        :return: выход той же формы

        Логика:
        - Применяется сигмоида к каждому элементу
        """
        return 1 / (1 + np.exp(-input))

    def compute_grad_input(self, input, grad_output):
        """
        Вычисляет градиент по входу.

        :param input: входной массив
        :param grad_output: градиент по выходу
        :return: градиент по входу

        Логика:
        - Производная сигмоиды:
            σ'(x) = σ(x) * (1 - σ(x))
        - grad_input = grad_output * σ'(x)
        """
        # your code here

        return grad_output * self.output * (1 - self.output)


class Softmax(Module):
    """
    Применяет Softmax по последнему измерению.
    """
    def compute_output(self, input):
        """
        :param input: массив размера (batch_size, num_classes)
        :return: массив того же размера

        Логика:
        - Для численной стабильности вычитаем max по последней оси
        - Применяем exp
        - Нормируем по сумме
        """
        x_ij = input - np.max(input, axis =-1, keepdims=True)

        return np.exp(x_ij) / np.sum (np.exp(x_ij), axis=-1, keepdims=True)

    def compute_grad_input(self, input, grad_output):
        """
        :param input: массив размера (batch_size, num_classes)
        :param grad_output: массив того же размера
        :return: градиент по входу

        Логика:
        - Производная softmax сложная: матрица Якоби.
        - В чистом виде:
            dL/dx_i = sum_j (softmax_i * (δ_{ij} - softmax_j)) * dL/dy_j
        - Обычно вычисляется упрощённо при совместном использовании с cross-entropy.
        """
        S = self.output
        dot = np.sum(grad_output * S, axis=-1, keepdims=True)
        return S * (grad_output - dot)


class LogSoftmax(Module):
    """
    Применяет LogSoftmax по последнему измерению.
    log_softmax(x_i) = x_i - log(sum_j exp(x_j))
    """

    def compute_output(self, input):
        """
        :param input: массив размера (batch_size, num_classes)
        :return: массив того же размера

        Логика:
        - Для стабильности вычитаем max
        - log_softmax = shifted - log(sum(exp(shifted)))

        Используйте функцию log_softmax из scipy.special
        """
        return log_softmax(input, axis=-1)

    def compute_grad_input(self, input, grad_output):
        """
        :param input: массив размера (batch_size, num_classes)
        :param grad_output: градиент по выходу
        :return: градиент по входу

        Логика:
        - d(log_softmax)/dx = I - softmax(x)
        - grad_input = grad_output - sum(grad_output * softmax, dim=-1)

        Реализация похожа на реализацию в классе Softmax, можете ориентироваться на нее
        """
        S = np.exp(self.output) # получили обычный софтмакс
        dot = np.sum(grad_output, axis=-1, keepdims=True)
        return grad_output - S * dot # посчитали производные